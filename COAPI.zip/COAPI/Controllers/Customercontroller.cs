﻿using COAPI.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

[ApiController]
[Route("api/[controller]/[action]")]
public class CustomerController : ControllerBase
{
    private readonly ICustomerRepository _customerRepository;
    private readonly ILogger<CustomerController> _logger;

    public CustomerController(ICustomerRepository customerRepository, ILogger<CustomerController> logger)
    {
        _customerRepository = customerRepository;
        _logger = logger;

    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
    {
        try
        {
            var customers = await _customerRepository.GetCustomersWithOrdersAsync();
            return Ok(customer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while fetching customers.");
            return StatusCode(500, "Internal server error. Please try again later.");
        }
    }


    [HttpGet]
    public async Task<ActionResult<Customer>> GetCustomer([FromQuery]string customerid)
    {
     

        try
        {
            var customer = await _customerRepository.GetCustomerWithOrdersAsync(customerid);
            return Ok(customer);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while fetching customers.");
            return StatusCode(500, "Internal server error. Please try again later.");
        }




    }




}

