﻿using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Text.Json;
using Newtonsoft.Json;



public class CustomerService
{
    private readonly HttpClient _httpClient;

    public CustomerService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<IEnumerable<Customer>> GetCustomersAsync()
    {
        var response = await _httpClient.GetAsync("api/customer/Getcustomers");
        response.EnsureSuccessStatusCode();

        var content = await response.Content.ReadAsStringAsync();
        Console.WriteLine(content); // Log the JSON content for debugging

        var customerList = new List<Customer>();

        try
        {
            var rootObject = JsonDocument.Parse(content);
            var customerArray = rootObject.RootElement.GetProperty("$values");

            foreach (var customerElement in customerArray.EnumerateArray())
            {
                var customer = new Customer
                {
                    CustomerID = customerElement.GetProperty("customerID").GetGuid(),
                    FirstName = customerElement.GetProperty("firstName").GetString(),
                    LastName = customerElement.GetProperty("lastName").GetString(),
                    DOB = customerElement.GetProperty("dob").GetDateTime(),
                    Orders = new List<Order>()
                };

                var ordersArray = customerElement.GetProperty("orders").GetProperty("$values");

                foreach (var orderElement in ordersArray.EnumerateArray())
                {
                    var order = new Order
                    {
                        OrderID = orderElement.GetProperty("orderID").GetInt32(),
                        CustomerID = orderElement.GetProperty("customerID").GetGuid(),
                        ItemName = orderElement.GetProperty("itemName").GetString(),
                        ItemPrice = orderElement.GetProperty("itemPrice").GetDecimal()
                    };

                    customer.Orders.Add(order);
                }

                customerList.Add(customer);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error parsing JSON: {ex.Message}");
        }

        return customerList;
    }


    public async Task<CustomerWrapper> GetCustomerWithOrdersAsync(Guid customerId)
    {
        var response = await _httpClient.GetAsync($"api/Customer/GetCustomer?customerid={customerId}");

        if (response.IsSuccessStatusCode)
        {
            var content = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<CustomerWrapper>(content);
        }

        throw new Exception("Error fetching customer data: " + response.ReasonPhrase);
    }
}









































/* public async Task<Customer> GetCustomerWithOrdersAsync(Guid CustomerId)
     {
         var response = await _httpClient.GetAsync($"api/customer/{CustomerId}");
         response.EnsureSuccessStatusCode(); // Throw if not success
         var content = await response.Content.ReadAsStringAsync();
         return JsonSerializer.Deserialize<Customer>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
     }
 */

/* public async Task<Customer> GetCustomerWithOrdersAsync(Guid customerId)
 {
     try
     {
         var response = await _httpClient.GetAsync($"http://localhost:7271/api/customers/{customerId}");
         response.EnsureSuccessStatusCode();

         var content = await response.Content.ReadAsStringAsync();

         // Handle the JSON structure
         var customerWrapper = JsonSerializer.Deserialize<CustomerWrapper>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
         var customer = customerWrapper?.Values?.FirstOrDefault();

         return customer;
     }
     catch (Exception ex)
     {
         Console.WriteLine($"Error fetching customer data: {ex.Message}");
         return null;
     }
 }*/



/*  public async Task<Customer> GetCustomerWithOrdersAsync(Guid customerId)
  {
      try
      {
          var response = await _httpClient.GetAsync($"http://localhost:7271/api/customers/{customerId}");
          response.EnsureSuccessStatusCode();

          var content = await response.Content.ReadAsStringAsync();
          var customer = JsonSerializer.Deserialize<Customer>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

          return customer;
      }
      catch (Exception ex)
      {
          Console.WriteLine($"Error fetching customer data: {ex.Message}");
          return null;
      }
  }*/




/* public async Task<CustomerWrapper> GetCustomerWithOrdersAsync(Guid customerId)
 {
     try
     {
         var response = await _httpClient.GetAsync($"http://localhost:7271/api/customers/{customerId}");
         response.EnsureSuccessStatusCode();

         var content = await response.Content.ReadAsStringAsync();

         // Deserialize into CustomerResponse
         var customerResponse = JsonSerializer.Deserialize<CustomerResponse>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

         // Extract the customer from the response
         var customer = customerResponse?.Values?.FirstOrDefault();

         // Handle the nested orders if needed
         if (customer != null && customer.Orders != null)
         {
             customer.Orders.Values = customer.Orders.Values ?? new List<OrderWrapper>();
         }

         return customer;
     }
     catch (Exception ex)
     {
         Console.WriteLine($"Error fetching customer data: {ex.Message}");
         return null;
     }
 }*/


/* public async Task<CustomerWrapper> GetCustomerWithOrdersAsync(Guid customerId)
 {
     try
     {
         var response = await _httpClient.GetAsync($"http://localhost:7271/api/customers/{customerId}");
         response.EnsureSuccessStatusCode();

         var content = await response.Content.ReadAsStringAsync();

         // Deserialize to the wrapper class
         var customerResponse = JsonSerializer.Deserialize<CustomerWrapper>(content, new JsonSerializerOptions
         {
             PropertyNameCaseInsensitive = true
         });

         return customerResponse;
     }
     catch (Exception ex)
     {
         Console.WriteLine($"Error fetching customer data: {ex.Message}");
         return null;
     }
 }

*/
/* public async Task<CustomerWrapper> GetCustomerWithOrdersAsync(Guid customerId)
 {
     try
     {
         var response = await _httpClient.GetAsync($"http://localhost:7271/api/customers/{customerId}");
         response.EnsureSuccessStatusCode();

         var content = await response.Content.ReadAsStringAsync();

         var customer = JsonSerializer.Deserialize<CustomerWrapper>(content, new JsonSerializerOptions
         {
             PropertyNameCaseInsensitive = true
         });

         return customer;
     }
     catch (Exception ex)
     {
         Console.WriteLine($"Error fetching customer data: {ex.Message}");
         return null;
     }
 }*/