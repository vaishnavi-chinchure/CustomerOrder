﻿
namespace COAPI.Repositories
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> GetCustomersWithOrdersAsync();
        Task<Customer> GetCustomerWithOrdersAsync(string customerid);


    }


}
